package br.com.caelum.jms;


import java.io.StringWriter;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.InitialContext;
import javax.xml.bind.JAXB;

import br.com.caelum.modelo.Pedido;
import br.com.caelum.modelo.PedidoFactory;

public class TestePublicadorTopico {

	public static void main(String[] args) throws Exception {
		Properties properties = new Properties();
		properties.setProperty("java.naming.factory.initial", "org.apache.activemq.jndi.ActiveMQInitialContextFactory");

		properties.setProperty("java.naming.provider.url", "tcp://localhost:61616");
		properties.setProperty("queue.financeiro", "fila.financeiro");
		properties.setProperty("topic.loja", "topico.loja");

		
		InitialContext context = new InitialContext(properties);
		ConnectionFactory factory = (ConnectionFactory) context.lookup("ConnectionFactory");
		
		Connection connection = factory.createConnection(); 
		//Connection connection = factory.createConnection("user", "senha");
		connection.start();
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		
		Destination fila = (Destination) context.lookup("loja");
		MessageProducer producer = session.createProducer(fila);
		for(int i = 0; i < 10; i ++) { 
			Pedido pedido = new PedidoFactory().geraPedidoComValores();
//			StringWriter writer = new StringWriter();
//
//			JAXB.marshal(pedido, writer);
//			
//			String xml = writer.toString();
			//Message message = session.createTextMessage(xml);
			Message message = session.createObjectMessage(pedido);
		    if(i%2==0){
		    	message.setBooleanProperty("ebook", false);
		    }else{
		    	message.setBooleanProperty("ebook", true);
		    }
		    producer.send(message);
		}
		
		session.close();
		connection.close();
		context.close();
	}
}
